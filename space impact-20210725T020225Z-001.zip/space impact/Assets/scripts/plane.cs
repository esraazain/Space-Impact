﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class plane : MonoBehaviour
{
    public Sprite planeDied;
    SpriteRenderer Sp;
    Animator anim;
    public manage manage;
    public score score;
    Rigidbody2D rb; //gravity
    public float speed;
    int angle;
    int maxAngle = 20;
    int minAngle = -90;
    bool touchedGround;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        Sp= GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update() 
    {
        if (manage.gameover == false)   //for flaying the plane 
        {
            AudioManager.audiomanager.Play("flay");
            if (Input.GetKey("up"))
            {
                transform.position = new Vector2(transform.position.x, transform.position.y + 2 * Time.deltaTime);
            }
            else if (Input.GetKey("down"))
            {
                transform.position = new Vector2(transform.position.x, transform.position.y - 2 * Time.deltaTime);
            }

        }
       // if (Input.GetMouseButtonDown(0) && manage.gameover==false)   //for flaying the plane 
       // {
       //     rb.velocity = Vector2.zero;
         //   rb.velocity = new Vector2(rb.velocity.x, speed);
       // }

        planeRotation();
    }
    void planeRotation()
    {
        if (rb.velocity.y > 0)
        {
            if (angle <= maxAngle)
            {
                angle = angle + 4;
            }
        }
        else if (rb.velocity.y < -1.2f)
        {
            if (angle >= minAngle)
            {
                angle = angle - 3;
            }
        }
        if (touchedGround == false)
        {
            transform.rotation = Quaternion.Euler(0, 0, angle);
        }
     
    }

   private void OnTriggerEnter2D(UnityEngine.Collider2D collision)
    {
        
        if (collision.CompareTag("evil"))
        {
           
            print("we have scored");
            AudioManager.audiomanager.Play("point");
            score.scored();
        }
        else if (collision.CompareTag("e"))
        {
            manage.GameOver();
            //game over
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("ground"))
        {
            if (manage.gameover == false)
            {
                //game over
                manage.GameOver();
                GameOver();

            }
            else
            {
                
                GameOver();
                //gameover(plane)
            }
        }

    }
    void GameOver()
    {
        touchedGround = true;
        anim.enabled = false;
        Sp.sprite = planeDied;
        transform.rotation = Quaternion.Euler(0, 0, -90);
    }
}
