﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;

public class evils : MonoBehaviour
{
     public float maxTime;
    float timer;
    public GameObject evil;
    public float maxY;
    public float minY;
      float randY;
    // Start is called before the first frame update
    void Start()
    {
        Instantiatevil();
    }

    // Update is called once per frame
    void Update()
    {
        if (manage.gameover == false)
        {
            timer += Time.deltaTime;
            if (timer >= maxTime)
            {
                Instantiatevil();
                timer = 0;
            }

        }

    }
    void Instantiatevil() {
     
        randY = UnityEngine.Random.Range(minY, maxY);
        GameObject newEvil = Instantiate(evil);
        newEvil.transform.position= new Vector2(transform.position.x,randY);
    }
}
