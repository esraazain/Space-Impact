﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveleft : MonoBehaviour
{
    public float speed;
    BoxCollider2D box;
    float groungwidth;
    public GameObject evil;
    float evilWidth;

    // Start is called before the first frame update
    void Start()
    {
        if (gameObject.CompareTag("ground") ){
            box = GetComponent<BoxCollider2D>();
            groungwidth = box.size.x;
        }
       else if (gameObject.CompareTag("evil"))
        {
            evilWidth = GameObject.FindGameObjectWithTag("e").GetComponent<BoxCollider2D>().size.x;
        }
        else if (gameObject.CompareTag("tree"))
        {
      
        }


    }

    // Update is called once per frame
    void Update()
    {
        if(manage.gameover == false)
        {
            transform.position = new Vector2(transform.position.x - speed * Time.deltaTime, transform.position.y);
        }
     
        if (gameObject.CompareTag("ground"))
        {
            if (transform.position.x <= -groungwidth)
            {
                transform.position = new Vector2(transform.position.x + 2 * groungwidth, transform.position.y);
            }
        }

        else if (gameObject.CompareTag("evil"))
        {
            if (transform.position.x < manage.bottomleft.x- evilWidth)
            {
                Destroy(gameObject);
            }
        }


    }
}
