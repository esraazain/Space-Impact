﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class manage : MonoBehaviour
{
    public GameObject GameOverCanvas;
    public GameObject score;
    //game states
    public static bool gameover;
    public static Vector2 bottomleft;

    public void AWake()
    {
        bottomleft = Camera.main.ScreenToWorldPoint(new Vector2(0, 0));
    }
    // Start is called before the first frame update
    void Start()
    {
        gameover = false;
    }
    public void GameOver()
    {
        gameover = true;
        score.SetActive(false);
        GameOverCanvas.SetActive(true);
    }

    public void OnOkBtnPressed()
    {
        AudioManager.audiomanager.Play("transition");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
