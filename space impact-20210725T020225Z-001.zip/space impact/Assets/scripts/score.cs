﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class score : MonoBehaviour
{
    int Score;
    int highScore;
    Text scoreText;
    public Text panelScore;
     public Text panelHighScore;
    // Start is called before the first frame update
    void Start()
    {
        
        Score = 0;
        scoreText = GetComponent<Text>();
        panelScore.text = Score.ToString();
        scoreText.text = Score.ToString();
        highScore = PlayerPrefs.GetInt("highScore");
        panelHighScore.text = highScore.ToString();

    }
     public void scored()
    {
        Score++;
        scoreText.text = Score.ToString();
        panelScore.text = Score.ToString();
        if (Score > highScore)
        {
            highScore= Score ;
            panelHighScore.text = highScore.ToString();
            PlayerPrefs.SetInt("highScore", highScore);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
